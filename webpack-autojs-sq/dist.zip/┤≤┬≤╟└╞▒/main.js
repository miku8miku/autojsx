"ui";
/**
 * 欢迎使用阿壹族插件. 官网: https://www.aezo.cn
**/
function a0_0x2400() {
    var _0x5357b2 = [
        '提交订单',
        'hasOwnProperty',
        '开始提交订单...',
        'rawWindow',
        'from',
        'clickDescAll',
        'xs_删除txt第一行',
        'closeApp',
        'toStringTag',
        '操作过于频繁...',
        'getMilliseconds',
        'children',
        'Set',
        'setTitle',
        'name',
        'll_perform_item',
        'forceStopApp',
        'test',
        '努力刷新',
        'ensureDir',
        '/material/getText?id=',
        'toString',
        'method',
        'exists',
        'findOne',
        'parents',
        'strToNumber',
        'waitTime',
        '开始选择身份证...',
        'resetConsole',
        'find',
        'backHomeReloadApp',
        '-->开始',
        '还是存在提交订单按钮，进入下一页失败...',
        'writeline',
        'updateDeviceStatus',
        'call',
        'needNum',
        'value',
        '../common/common.js',
        'map',
        'body',
        'getMinutes',
        'Module',
        'setCanInput',
        'iterator',
        'jianlou',
        'split',
        '找到唯一场次...',
        'remove',
        'clickXy',
        'img_jia',
        'origin',
        'string',
        '找到匹配票档...',
        'xs_读取txt数组内容',
        'getSeconds',
        'debugXy',
        'width',
        'vibrate',
        'index',
        'saveInfo',
        'forEach',
        'apply',
        '已解除操作频繁限制...',
        'clickXyRect',
        'deviceHeight',
        'parent',
        '点击努力刷新/继续尝试...',
        'join',
        'http://112.74.161.35:9317',
        'options-->',
        'textToList',
        'get',
        '/appuser/update',
        'getDate',
        'push',
        '#ff11ee00',
        'Object',
        'put',
        'pdArr',
        'prototype',
        'exports',
        ').*/',
        'swipeToTopRandom',
        'timeToSec',
        'run',
        'setLogSize',
        'isArray',
        'openApp',
        'next',
        'findOnce',
        'setSize',
        'getFullYear',
        '未知状态...',
        'bounds',
        'json',
        'default',
        'swipeToRightRandom',
        'contains',
        'untilFind',
        'getIMEI',
        'userCode',
        'Arguments',
        'centerX',
        'saveObj',
        'back',
        'xs_叠加写入文本',
        '找到预售，开始匹配场次...',
        'getMonth',
        'click',
        'create',
        'xs_删除写入文本',
        'error',
        'getVirtualBarHeigh',
        '找到匹配场次...',
        'swipeRandom',
        'concat',
        'substr',
        'setPosition',
        '开始匹配票档...',
        'replace',
        'Map',
        '努力刷新/继续尝试...',
        '\x0a\x20\x20<vertical>\x0a\x20\x20\x20\x20\x20\x20<text\x20textSize=\x2218sp\x22\x20textColor=\x22red\x22\x20gravity=\x22center\x22\x20margin=\x2220\x22\x20textStyle=\x22bold\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20请输入抢票信息\x0a\x20\x20\x20\x20\x20\x20</text>\x0a\x20\x20\x20\x20\x20\x20<ScrollView>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<vertical>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<text\x20textSize=\x2216sp\x22\x20margin=\x228\x22>抢票类型</text>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<RadioGroup\x20android:orientation=\x22horizontal\x22\x20>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<RadioButton\x20id=\x22yuding\x22\x20text=\x22预定\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<RadioButton\x20id=\x22goumai\x22\x20text=\x22购买\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<RadioButton\x20id=\x22jianlou\x22\x20text=\x22捡漏\x22\x20checked=\x22true\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</RadioGroup>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<text\x20textSize=\x2216sp\x22\x20margin=\x228\x22>场次</text>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20id=\x22ccArr\x22\x20text=\x22\x22\x20margin=\x220\x2016\x22\x20w=\x22*\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<text\x20textSize=\x2216sp\x22\x20margin=\x228\x22>票档</text>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20id=\x22pdArr\x22\x20text=\x22\x22\x20margin=\x220\x2016\x22\x20w=\x22*\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<text\x20textSize=\x2216sp\x22\x20margin=\x228\x22>张数</text>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20id=\x22needNum\x22\x20text=\x222\x22\x20inputType=\x22number\x22\x20margin=\x220\x2016\x22\x20w=\x22*\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<linear\x20gravity=\x22center\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22runBtn\x22\x20margin=\x2216\x22\x20textColor=\x22red\x22>开始抢票</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22cancelBtn\x22\x20margin=\x2216\x22>取消</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</linear>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</vertical>\x0a\x20\x20\x20\x20\x20\x20</ScrollView>\x0a\x20\x20</vertical>\x0a',
        'moveTaskToBack',
        '/.*(立即购买|立即预定|立即预订).*/',
        'getRandomMsg',
        'yuding',
        'getAndroidId',
        'utf-8',
        'postJson',
        '缺货登记',
        'length',
        'height',
        'httptext',
        'callee',
        'userId',
        'text',
        'layout',
        '继续尝试',
        'readlines',
        'runBtn',
        'swipeToLeftRandom',
        'close',
        'getDeviceCode',
        'filter',
        'layout_price',
        'isChecked',
        'stringIsBlank',
        '开始选择票数...',
        'write',
        '\x0a\x20\x20\x20\x20<frame\x20gravity=\x22center\x22\x20bg=\x22#77ff0000\x22>\x0a\x20\x20\x20\x20\x20\x20<text\x20id=\x22text\x22>XX</text>\x0a\x20\x20\x20\x20</frame>\x0a\x20\x20',
        '操作过于频繁',
        '关闭应用',
        '/.*(',
        'xs_读取txt第一行',
        'goumai',
        'show',
        'obj',
        '开始确定...',
        'deviceCode',
        '次找到按钮...',
        'read',
        'defineProperty',
        'visibleToUser',
        '__esModule',
        'undefined',
        'trim',
        'debugXy:',
        '身份证',
        'timestampToHMS',
        '开始匹配场次...',
        'clickable',
        'forceStop',
        'noResponse',
        'getHours',
        'message',
        '已点击立即购买...',
        '我知道了',
        'clear',
        'floor',
        'number',
        '/device/updateStatusByImei?imei',
        'done',
        'textContains',
        'bind',
        'consoleWrap',
        'log',
        'centerY',
        'ccArr'
    ];
    a0_0x2400 = function () {
        return _0x5357b2;
    };
    return a0_0x2400();
}
function a0_0xc4af(_0x25d8bf, _0x24004b) {
    var _0xc4afe5 = a0_0x2400();
    return a0_0xc4af = function (_0x4b9c3c, _0x4d1e62) {
        _0x4b9c3c = _0x4b9c3c - 0x1ba;
        var _0xb711a7 = _0xc4afe5[_0x4b9c3c];
        return _0xb711a7;
    }, a0_0xc4af(_0x25d8bf, _0x24004b);
}
(function (_0x4785d1) {
    var _0x453c03 = {};
    function _0x38b6a9(_0xc5cac) {
        var _0x1cd8b4 = a0_0xc4af;
        if (_0x453c03[_0xc5cac])
            return _0x453c03[_0xc5cac][_0x1cd8b4(0x20c)];
        var _0x19a2fc = _0x453c03[_0xc5cac] = {
            'i': _0xc5cac,
            'l': ![],
            'exports': {}
        };
        return _0x4785d1[_0xc5cac]['call'](_0x19a2fc[_0x1cd8b4(0x20c)], _0x19a2fc, _0x19a2fc[_0x1cd8b4(0x20c)], _0x38b6a9), _0x19a2fc['l'] = !![], _0x19a2fc[_0x1cd8b4(0x20c)];
    }
    return _0x38b6a9['m'] = _0x4785d1, _0x38b6a9['c'] = _0x453c03, _0x38b6a9['d'] = function (_0x28216a, _0x35cd22, _0x5418a6) {
        var _0x400f6b = a0_0xc4af;
        !_0x38b6a9['o'](_0x28216a, _0x35cd22) && Object[_0x400f6b(0x25e)](_0x28216a, _0x35cd22, {
            'enumerable': !![],
            'get': _0x5418a6
        });
    }, _0x38b6a9['r'] = function (_0xa2c13f) {
        var _0x57cb27 = a0_0xc4af;
        typeof Symbol !== 'undefined' && Symbol[_0x57cb27(0x1c2)] && Object['defineProperty'](_0xa2c13f, Symbol[_0x57cb27(0x1c2)], { 'value': _0x57cb27(0x1e5) }), Object[_0x57cb27(0x25e)](_0xa2c13f, _0x57cb27(0x260), { 'value': !![] });
    }, _0x38b6a9['t'] = function (_0x26b819, _0x3d7a1a) {
        var _0x51985e = a0_0xc4af;
        if (_0x3d7a1a & 0x1)
            _0x26b819 = _0x38b6a9(_0x26b819);
        if (_0x3d7a1a & 0x8)
            return _0x26b819;
        if (_0x3d7a1a & 0x4 && typeof _0x26b819 === 'object' && _0x26b819 && _0x26b819['__esModule'])
            return _0x26b819;
        var _0x3113a8 = Object[_0x51985e(0x229)](null);
        _0x38b6a9['r'](_0x3113a8), Object[_0x51985e(0x25e)](_0x3113a8, _0x51985e(0x21b), {
            'enumerable': !![],
            'value': _0x26b819
        });
        if (_0x3d7a1a & 0x2 && typeof _0x26b819 != 'string') {
            for (var _0x4497f8 in _0x26b819)
                _0x38b6a9['d'](_0x3113a8, _0x4497f8, function (_0x247529) {
                    return _0x26b819[_0x247529];
                }[_0x51985e(0x274)](null, _0x4497f8));
        }
        return _0x3113a8;
    }, _0x38b6a9['n'] = function (_0x757a89) {
        var _0x3ac3d2 = a0_0xc4af, _0x2eafc1 = _0x757a89 && _0x757a89[_0x3ac3d2(0x260)] ? function _0x318a76() {
                var _0x41169a = _0x3ac3d2;
                return _0x757a89[_0x41169a(0x21b)];
            } : function _0x544017() {
                return _0x757a89;
            };
        return _0x38b6a9['d'](_0x2eafc1, 'a', _0x2eafc1), _0x2eafc1;
    }, _0x38b6a9['o'] = function (_0x1cc8d6, _0x711e66) {
        var _0x31a8e7 = a0_0xc4af;
        return Object[_0x31a8e7(0x20b)][_0x31a8e7(0x1bb)][_0x31a8e7(0x1de)](_0x1cc8d6, _0x711e66);
    }, _0x38b6a9['p'] = '', _0x38b6a9(_0x38b6a9['s'] = '../work/大麦抢票/main.js');
}({
    '../common/common.js': function (_0x227039, _0x37a9c5) {
        var _0x154bd7 = a0_0xc4af, _0x5a4003 = {};
        _0x5a4003[_0x154bd7(0x1f6)] = 0x0, _0x5a4003[_0x154bd7(0x1d7)] = function (_0x1f07e2, _0x4b47bc, _0x477bee, _0x440074) {
            var _0x1f9635 = _0x154bd7;
            console[_0x1f9635(0x258)](!![]), _0x1f07e2 = _0x1f07e2 || 0x0, _0x4b47bc = _0x4b47bc || 0x0, _0x477bee = _0x477bee || device[_0x1f9635(0x1f4)] * 0.7, _0x440074 = _0x440074 || device[_0x1f9635(0x240)] * 0.2, sleep(0x3e8), console['setPosition'](_0x1f07e2, _0x4b47bc), sleep(0x3e8), ui[_0x1f9635(0x210)](function () {
                var _0x46e162 = _0x1f9635;
                console[_0x46e162(0x216)](_0x477bee, _0x440074), console[_0x46e162(0x1e6)](![]), console[_0x46e162(0x1c7)]('', _0x46e162(0x207), 0x1e), console[_0x46e162(0x211)](0x8);
            });
        }, _0x5a4003['setConsoleTitle'] = function (_0x3f551f, _0x4e5374, _0x25e194) {
            var _0x507633 = _0x154bd7;
            console[_0x507633(0x1c7)](_0x3f551f, _0x4e5374, _0x25e194);
        }, _0x5a4003[_0x154bd7(0x1d5)] = function (_0x260def, _0x5dd291) {
            var _0x4ae7de = _0x154bd7, _0x3f72bf = _0x260def, _0x1c622e = _0x5dd291 || '倒计时';
            if (0x1 > _0x260def && _0x260def > 0x0) {
                _0x5a4003['index']++, log(_0x1c622e), sleep(_0x260def * 0x3e8);
                return;
            }
            var _0x11f93c = !![];
            while (_0x3f72bf >= 0x0) {
                _0x11f93c = !![], _0x3f72bf > 0x64 && _0x3f72bf % 0x5 != 0x0 && (_0x11f93c = ![]), _0x11f93c && _0x3f72bf > 0x0 && log(_0x1c622e + '-->' + _0x3f72bf), _0x3f72bf % 0x5 == 0x0 && _0x5a4003[_0x4ae7de(0x1f6)]++, _0x3f72bf != 0x0 && sleep(0x3e8), _0x3f72bf--;
            }
        }, _0x5a4003[_0x154bd7(0x275)] = function (_0x1d4718, _0x1dc448, _0x25ae20) {
            var _0x49f6b3 = _0x154bd7;
            log(_0x49f6b3(0x1da) + _0x1d4718);
            if (_0x25ae20)
                try {
                    _0x1dc448();
                } catch (_0x2369da) {
                    console[_0x49f6b3(0x22b)](_0x2369da);
                }
            else
                _0x1dc448();
            log('<--结束' + _0x1d4718);
        }, _0x5a4003[_0x154bd7(0x1f3)] = function (_0x2daedc, _0x4ffbbd) {
            var _0x4e01e8 = _0x154bd7, _0x1e54ca = floaty[_0x4e01e8(0x1bd)](_0x4e01e8(0x252));
            _0x1e54ca[_0x4e01e8(0x231)](_0x2daedc - 0x1e, _0x4ffbbd - 0x6e), console[_0x4e01e8(0x276)](_0x4e01e8(0x263), _0x2daedc, _0x4ffbbd);
        }, _0x5a4003[_0x154bd7(0x213)] = function (_0x265090) {
            launchApp(_0x265090);
        }, _0x5a4003[_0x154bd7(0x1c1)] = function (_0x26e066) {
            var _0x26deec = 0x0;
            while (_0x26deec < 0x5) {
                back(), sleep(0x3e8), _0x26deec++;
            }
            back(), sleep(0x3e8), back();
        }, _0x5a4003[_0x154bd7(0x1d9)] = function (_0x40a662) {
            var _0x24466c = _0x154bd7;
            _0x5a4003[_0x24466c(0x1c1)](_0x40a662), sleep(0x3e8), _0x5a4003[_0x24466c(0x213)](_0x40a662);
        }, _0x5a4003[_0x154bd7(0x1fc)] = function () {
            var _0x2ef709 = _0x154bd7;
            return device[_0x2ef709(0x240)] - device[_0x2ef709(0x22c)]();
        }, _0x5a4003[_0x154bd7(0x1d3)] = function (_0x2255e5, _0x5675e1) {
            var _0x1a79d5 = _0x154bd7;
            this[_0x1a79d5(0x259)] = _0x2255e5;
            for (var _0x5234c1 = 0x0; _0x5234c1 < _0x5675e1; _0x5234c1++) {
                this[_0x1a79d5(0x259)] = this[_0x1a79d5(0x259)]['parent']();
            }
            return this[_0x1a79d5(0x259)];
        }, _0x5a4003[_0x154bd7(0x1ec)] = function (_0x42e29e, _0x37a1d6, _0x344e26) {
            var _0x295802 = _0x154bd7;
            if (!_0x42e29e)
                return;
            if (_0x37a1d6 !== ![]) {
                var _0xabc0f7 = _0x42e29e[_0x295802(0x219)]();
                _0x344e26 === !![] && (_0x344e26 = 0xc8);
                if (_0x344e26)
                    return press(_0xabc0f7[_0x295802(0x222)](), _0xabc0f7[_0x295802(0x277)](), _0x344e26);
                return click(_0xabc0f7[_0x295802(0x222)](), _0xabc0f7[_0x295802(0x277)]());
            } else
                return _0x42e29e[_0x295802(0x267)]() ? _0x42e29e[_0x295802(0x228)]() : arguments[_0x295802(0x242)](_0x42e29e[_0x295802(0x1fd)]());
        }, _0x5a4003[_0x154bd7(0x1fb)] = function (_0x1979f8) {
            var _0x5ed0ca = _0x154bd7, _0x32c1ef = arguments[_0x5ed0ca(0x23f)] > 0x1 && arguments[0x1] !== undefined ? arguments[0x1] : 0xa;
            if (!_0x1979f8)
                return;
            var _0x3ee887 = _0x1979f8['bounds']();
            return click(_0x3ee887[_0x5ed0ca(0x222)]() - _0x32c1ef, _0x3ee887[_0x5ed0ca(0x277)]() - _0x32c1ef, _0x3ee887['centerX']() + _0x32c1ef, _0x3ee887[_0x5ed0ca(0x277)]() + _0x32c1ef);
        }, _0x5a4003[_0x154bd7(0x1bf)] = function (_0x4eb401) {
            var _0x116ef1 = _0x154bd7, _0x328f9d = desc(_0x4eb401)[_0x116ef1(0x1d8)]();
            console['warn'](_0x328f9d), _0x328f9d[_0x116ef1(0x1f8)](function (_0x5e8829) {
                var _0x115869 = _0x116ef1;
                _0x5e8829[_0x115869(0x228)](), _0x5a4003[_0x115869(0x1d5)](random(0x320, 0x4b0), '点击' + _0x4eb401);
            });
        }, _0x5a4003[_0x154bd7(0x25f)] = function (_0x212cd8, _0xea89a1) {
            var _0x26dd3c = _0x154bd7, _0x37fe72 = null;
            try {
                _0x37fe72 = _0x212cd8['visibleToUser'](!![])[_0x26dd3c(0x1d2)](0xa);
                if (_0x37fe72 != null)
                    return _0xea89a1 && _0x37fe72[_0x26dd3c(0x228)](), !![];
            } catch (_0x995da8) {
                log(_0x995da8);
            }
            return ![];
        }, _0x5a4003[_0x154bd7(0x273)] = function (_0xf9639f, _0x546604) {
            var _0x20bd7b = _0x154bd7;
            if (_0xf9639f) {
                var _0x2d0692 = textContains(_0xf9639f)[_0x20bd7b(0x1d2)](0x3e8);
                return _0x2d0692 != null ? (_0x2d0692 = _0x2d0692[_0x20bd7b(0x244)](), _0x546604 ? click(_0x2d0692) : !![]) : ![];
            }
        }, _0x5a4003[_0x154bd7(0x21c)] = function () {
            var _0x256394 = _0x154bd7;
            _0x5a4003['swipeRandom'](device[_0x256394(0x1f4)] * 0.7, device[_0x256394(0x240)] * 0.55, device[_0x256394(0x1f4)] * 0.3, device[_0x256394(0x240)] * 0.55, random(0x5dc, 0x7d0));
        }, _0x5a4003[_0x154bd7(0x249)] = function () {
            var _0x42529d = _0x154bd7;
            _0x5a4003[_0x42529d(0x22e)](device[_0x42529d(0x1f4)] * 0.3, device[_0x42529d(0x240)] * 0.55, device[_0x42529d(0x1f4)] * 0.7, device[_0x42529d(0x240)] * 0.55, random(0x5dc, 0x7d0));
        }, _0x5a4003[_0x154bd7(0x20e)] = function () {
            var _0x3b415b = _0x154bd7;
            _0x5a4003['swipeRandom'](device['width'] * 0.55, device[_0x3b415b(0x240)] * 0.8, device[_0x3b415b(0x1f4)] * 0.55, device[_0x3b415b(0x240)] * 0.4, random(0x5dc, 0x7d0));
        }, _0x5a4003['swipeToBottomRandom'] = function () {
            var _0xfb906 = _0x154bd7;
            _0x5a4003[_0xfb906(0x22e)](device[_0xfb906(0x1f4)] * 0.55, device[_0xfb906(0x240)] * 0.4, device[_0xfb906(0x1f4)] * 0.55, device[_0xfb906(0x240)] * 0.8, random(0x5dc, 0x7d0));
        }, _0x5a4003['swipeRandom'] = function (_0x1b0729, _0x30e09b, _0x18d4b8, _0x5d1baa, _0x8cd216) {
            var _0x2035dd = _0x154bd7, _0x22a01a = [_0x8cd216], _0x791e36 = [], _0x48973b = {
                    'x': _0x1b0729,
                    'y': _0x30e09b
                }, _0x459f45 = {
                    'x': random(_0x1b0729 - 0x64, _0x1b0729 + 0x64),
                    'y': random(_0x30e09b, _0x30e09b + 0x32)
                }, _0x5a4e2c = {
                    'x': random(_0x18d4b8 - 0x64, _0x18d4b8 + 0x64),
                    'y': random(_0x5d1baa, _0x5d1baa + 0x32)
                }, _0x298dea = {
                    'x': _0x18d4b8,
                    'y': _0x5d1baa
                };
            _0x791e36['push'](_0x48973b), _0x791e36[_0x2035dd(0x206)](_0x459f45), _0x791e36[_0x2035dd(0x206)](_0x5a4e2c), _0x791e36[_0x2035dd(0x206)](_0x298dea);
            for (var _0x17c9ac = 0x0; _0x17c9ac < 1.2; _0x17c9ac += 0.08) {
                var _0x41bd98 = [
                    parseInt(_0xd874cc(_0x791e36, _0x17c9ac)['x']),
                    parseInt(_0xd874cc(_0x791e36, _0x17c9ac)['y'])
                ];
                _0x22a01a[_0x2035dd(0x206)](_0x41bd98);
            }
            gesture[_0x2035dd(0x1f9)](null, _0x22a01a);
        };
        function _0xd874cc(_0x2a05ca, _0x8abfca) {
            var _0x220b82 = 0x3 * (_0x2a05ca[0x1]['x'] - _0x2a05ca[0x0]['x']), _0x168973 = 0x3 * (_0x2a05ca[0x2]['x'] - _0x2a05ca[0x1]['x']) - _0x220b82, _0x27e16d = _0x2a05ca[0x3]['x'] - _0x2a05ca[0x0]['x'] - _0x220b82 - _0x168973, _0x2f4fb4 = 0x3 * (_0x2a05ca[0x1]['y'] - _0x2a05ca[0x0]['y']), _0x301948 = 0x3 * (_0x2a05ca[0x2]['y'] - _0x2a05ca[0x1]['y']) - _0x2f4fb4, _0x13175f = _0x2a05ca[0x3]['y'] - _0x2a05ca[0x0]['y'] - _0x2f4fb4 - _0x301948, _0x40f471 = _0x8abfca * _0x8abfca, _0x441892 = _0x40f471 * _0x8abfca, _0x523319 = {
                    'x': 0x0,
                    'y': 0x0
                };
            return _0x523319['x'] = _0x27e16d * _0x441892 + _0x168973 * _0x40f471 + _0x220b82 * _0x8abfca + _0x2a05ca[0x0]['x'], _0x523319['y'] = _0x13175f * _0x441892 + _0x301948 * _0x40f471 + _0x2f4fb4 * _0x8abfca + _0x2a05ca[0x0]['y'], _0x523319;
        }
        _0x5a4003[_0x154bd7(0x247)] = function (_0x470a2c) {
            var _0x59311a = _0x154bd7;
            files[_0x59311a(0x1cd)](_0x470a2c);
            !files['exists'](_0x470a2c) && files[_0x59311a(0x229)](_0x470a2c);
            var _0xfbdd3a = files['open'](_0x470a2c, 'r')['readlines']();
            return _0xfbdd3a;
        }, _0x5a4003[_0x154bd7(0x239)] = function (_0x443de5) {
            var _0x11c91d = random(0x0, _0x443de5['length'] - 0x1);
            return _0x443de5[_0x11c91d];
        }, _0x5a4003[_0x154bd7(0x20f)] = function (_0xb4becb) {
            var _0x269154 = _0x154bd7, _0x36e862 = _0xb4becb[_0x269154(0x1e9)](':')[0x0], _0x2b19fc = _0xb4becb['split'](':')[0x1], _0x518a88 = Number(_0x36e862 * 0x3c) + Number(_0x2b19fc);
            return _0x518a88;
        }, _0x5a4003[_0x154bd7(0x265)] = function (_0x435df8) {
            var _0x150b1e = _0x154bd7, _0x3f639b = new Date(Number(_0x435df8)), _0x30346e = (_0x3f639b[_0x150b1e(0x26a)]() < 0xa ? '0' + _0x3f639b['getHours']() : '' + _0x3f639b[_0x150b1e(0x26a)]()) + ':', _0x577d56 = (_0x3f639b[_0x150b1e(0x1e4)]() < 0xa ? '0' + _0x3f639b['getMinutes']() : '' + _0x3f639b[_0x150b1e(0x1e4)]()) + ':', _0x1b3eb9 = _0x3f639b[_0x150b1e(0x1f2)]() < 0xa ? '0' + _0x3f639b[_0x150b1e(0x1f2)]() : '' + _0x3f639b['getSeconds']();
            return _0x30346e + _0x577d56 + _0x1b3eb9;
        }, _0x5a4003[_0x154bd7(0x202)] = function (_0x3246e1) {
            var _0x13c966 = _0x154bd7, _0x1f2109 = _0x3246e1[_0x13c966(0x1e9)]('\x0a');
            return _0x1f2109 = _0x1f2109['filter'](function (_0x5e54b5) {
                var _0x3be2b7 = _0x13c966;
                return _0x5e54b5 && _0x5e54b5[_0x3be2b7(0x262)]();
            }), _0x1f2109;
        };
        var _0x2b5fbe = 'cslcommon';
        _0x5a4003[_0x154bd7(0x223)] = function (_0x5ecc9d, _0x3ca3e2) {
            var _0x3197e3 = _0x154bd7, _0x238aee = storages[_0x3197e3(0x229)](_0x2b5fbe);
            _0x238aee[_0x3197e3(0x209)](_0x5ecc9d, _0x3ca3e2);
        }, _0x5a4003['getObj'] = function (_0x3d51fd) {
            var _0x28aff8 = _0x154bd7, _0x384a03 = storages[_0x28aff8(0x229)](_0x2b5fbe);
            return _0x384a03[_0x28aff8(0x203)](_0x3d51fd);
        }, _0x5a4003[_0x154bd7(0x21d)] = function (_0x43a9de) {
            var _0x585ec = _0x154bd7, _0x1d1aac = storages[_0x585ec(0x229)](_0x2b5fbe);
            return _0x1d1aac[_0x585ec(0x21d)](_0x43a9de);
        }, _0x5a4003['remove'] = function (_0x160329) {
            var _0x13511a = _0x154bd7, _0xd5d866 = storages['create'](_0x2b5fbe);
            _0xd5d866[_0x13511a(0x1eb)](_0x160329);
        }, _0x5a4003[_0x154bd7(0x26e)] = function () {
            var _0xeca402 = _0x154bd7, _0x298950 = storages[_0xeca402(0x229)](_0x2b5fbe);
            _0x298950[_0xeca402(0x26e)]();
        }, _0x5a4003[_0x154bd7(0x241)] = function (_0x29455a) {
            var _0x371ec2 = _0x154bd7;
            try {
                var _0x1b0332 = http['get'](_0x5a4003['origin'] + _0x371ec2(0x1ce) + _0x29455a);
                return _0x1b0332[_0x371ec2(0x1e3)][_0x371ec2(0x21a)]();
            } catch (_0x581506) {
                console[_0x371ec2(0x276)](_0x581506);
            }
            return {};
        }, _0x5a4003['dateFormat'] = function (_0x5b0372, _0x34e43d) {
            var _0x4501a8 = _0x154bd7, _0x333e4b = {
                    'M+': _0x34e43d[_0x4501a8(0x227)]() + 0x1,
                    'd+': _0x34e43d[_0x4501a8(0x205)](),
                    'h+': _0x34e43d[_0x4501a8(0x26a)](),
                    'm+': _0x34e43d[_0x4501a8(0x1e4)](),
                    's+': _0x34e43d[_0x4501a8(0x1f2)](),
                    'q+': Math[_0x4501a8(0x26f)]((_0x34e43d[_0x4501a8(0x227)]() + 0x3) / 0x3),
                    'S': _0x34e43d[_0x4501a8(0x1c4)]()
                };
            /(y+)/['test'](_0x5b0372) && (_0x5b0372 = _0x5b0372[_0x4501a8(0x233)](RegExp['$1'], (_0x34e43d[_0x4501a8(0x217)]() + '')[_0x4501a8(0x230)](0x4 - RegExp['$1'][_0x4501a8(0x23f)])));
            for (var _0x39eaf2 in _0x333e4b) {
                new RegExp('(' + _0x39eaf2 + ')')[_0x4501a8(0x1cb)](_0x5b0372) && (_0x5b0372 = _0x5b0372[_0x4501a8(0x233)](RegExp['$1'], RegExp['$1']['length'] == 0x1 ? _0x333e4b[_0x39eaf2] : ('00' + _0x333e4b[_0x39eaf2])[_0x4501a8(0x230)](('' + _0x333e4b[_0x39eaf2])[_0x4501a8(0x23f)])));
            }
            return _0x5b0372;
        }, _0x5a4003['init'] = function (_0x39580b) {
            var _0x1a18a0 = _0x154bd7;
            _0x5a4003['userCode'] = _0x39580b[_0x1a18a0(0x220)] || 0x2, _0x5a4003['origin'] = _0x39580b[_0x1a18a0(0x1ee)] || _0x1a18a0(0x200), _0x5a4003['deviceCode'] = this[_0x1a18a0(0x24b)]();
        }, _0x5a4003[_0x154bd7(0x1d4)] = function (_0x2782bb) {
            var _0x4cdc04 = 0x1;
            return _0x2782bb['indexOf']('w') != -0x1 && (_0x4cdc04 = 0x2710), parseInt(_0x2782bb['replace']('w', '')) * parseInt(_0x4cdc04);
        }, _0x5a4003['getDeviceCode'] = function () {
            var _0x5cd624 = _0x154bd7;
            return !_0x5a4003['deviceCode'] && (_0x5a4003['deviceCode'] = device[_0x5cd624(0x21f)]() || device[_0x5cd624(0x23b)]()), _0x5a4003[_0x5cd624(0x25b)];
        }, _0x5a4003[_0x154bd7(0x24f)] = function (_0x58e72a) {
            if (_0x58e72a == null || _0x58e72a == undefined || _0x58e72a == '' || _0x58e72a == 'undefined')
                return !![];
            return ![];
        }, _0x5a4003[_0x154bd7(0x1dd)] = function () {
            var _0x5da877 = _0x154bd7, _0x31df3a = arguments[_0x5da877(0x23f)] > 0x0 && arguments[0x0] !== undefined ? arguments[0x0] : _0x31df3a || 0x1, _0x29f13c = _0x5a4003[_0x5da877(0x1ee)] + _0x5da877(0x271) + this[_0x5da877(0x24b)]() + '&status=' + _0x31df3a, _0xe645c6 = http[_0x5da877(0x203)](_0x29f13c), _0x7abc2b = _0xe645c6[_0x5da877(0x1e3)][_0x5da877(0x21a)]();
            console['log'](_0x7abc2b);
        }, _0x5a4003[_0x154bd7(0x1ca)] = function (_0x298bc1) {
            var _0x5823a2 = _0x154bd7;
            try {
                shell('am\x20force-stop\x20' + _0x298bc1, !![]);
            } catch (_0x5dce78) {
                console[_0x5823a2(0x276)](_0x5dce78);
            }
        }, _0x5a4003[_0x154bd7(0x269)] = function () {
            var _0x201649 = _0x154bd7, _0x22b5b3;
            if (text('等待')[_0x201649(0x215)]() && (_0x22b5b3 = text(_0x201649(0x254))[_0x201649(0x215)]()))
                return _0x22b5b3['click'](), sleep(0x3e8), !![];
            return ![];
        }, _0x5a4003['topClickedView'] = function (_0x2eda88) {
            var _0x3fa5aa = _0x154bd7;
            while (_0x2eda88 && !_0x2eda88[_0x3fa5aa(0x267)]()) {
                _0x2eda88 = _0x2eda88[_0x3fa5aa(0x1fd)]();
            }
            return _0x2eda88;
        }, _0x5a4003[_0x154bd7(0x22a)] = function (_0x941e9, _0x19491d) {
            var _0x5c2e16 = _0x154bd7;
            file = open(_0x941e9, 'w'), file[_0x5c2e16(0x251)](_0x19491d), file[_0x5c2e16(0x24a)]();
        }, _0x5a4003[_0x154bd7(0x225)] = function (_0x59c097, _0x38e911) {
            var _0x668bf8 = _0x154bd7;
            file = open(_0x59c097, 'a'), file[_0x668bf8(0x1dc)](_0x38e911), file['close']();
        }, _0x5a4003[_0x154bd7(0x256)] = function (_0x568740, _0xd5e2cf) {
            var _0x453005 = _0x154bd7, _0x5616d3 = open(_0x568740, 'r', _0xd5e2cf), _0x379beb = _0x5616d3[_0x453005(0x247)]();
            _0x5616d3['close']();
            for (a in _0x379beb) {
                if (a == 0x0)
                    return _0x379beb[a];
            }
        }, _0x5a4003['xs_读取txt全部内容'] = function (_0x26a80d, _0x45b358) {
            var _0x31aa77 = _0x154bd7, _0x5c9e38 = open(_0x26a80d, 'r', _0x45b358), _0x379d40 = _0x5c9e38[_0x31aa77(0x25d)]();
            return _0x5c9e38[_0x31aa77(0x24a)](), _0x379d40;
        }, _0x5a4003[_0x154bd7(0x1f1)] = function (_0x3ba5ba, _0x32f7c5) {
            var _0xc0114 = _0x154bd7, _0x887a6e = open(_0x3ba5ba, 'r', _0x32f7c5), _0x475ab6 = _0x887a6e[_0xc0114(0x247)]();
            return _0x887a6e[_0xc0114(0x24a)](), _0x475ab6;
        }, _0x5a4003[_0x154bd7(0x1c0)] = function (_0x551779) {
            var _0x3db2fa = _0x154bd7, _0x4b3a3e = open(_0x551779, 'r', _0x3db2fa(0x23c)), _0x4c8003 = _0x4b3a3e['readlines']();
            _0x4b3a3e[_0x3db2fa(0x24a)](), files[_0x3db2fa(0x1eb)](_0x551779), files['createWithDirs'](_0x551779);
            var _0x28fea1 = open(_0x551779, 'w', _0x3db2fa(0x23c));
            for (a in _0x4c8003) {
                a != 0x0 && _0x28fea1[_0x3db2fa(0x251)](_0x4c8003[a] + '\x0d\x0a');
            }
            return _0x28fea1['close'](), _0x4c8003[0x1];
        }, _0x5a4003[_0x154bd7(0x1f7)] = function (_0x5b9a80) {
            var _0x57e859 = _0x154bd7, _0x2158aa = _0x5a4003[_0x57e859(0x1ee)] + _0x57e859(0x204);
            _0x5b9a80[_0x57e859(0x243)] = _0x5a4003[_0x57e859(0x220)], _0x5b9a80[_0x57e859(0x25b)] = _0x5a4003[_0x57e859(0x24b)]();
            try {
                var _0x12711d = http[_0x57e859(0x23d)](_0x2158aa, _0x5b9a80);
                console[_0x57e859(0x276)](_0x12711d[_0x57e859(0x1e3)][_0x57e859(0x21a)]());
            } catch (_0x247838) {
                console[_0x57e859(0x276)](_0x247838);
            }
        }, _0x5a4003['checkFile'] = function (_0x4dda41) {
            var _0x140f8f = _0x154bd7;
            files[_0x140f8f(0x1cd)](_0x4dda41), !files[_0x140f8f(0x1d1)](_0x4dda41) && files['create'](_0x4dda41);
        }, _0x227039[_0x154bd7(0x20c)] = _0x5a4003;
    },
    '../work/大麦抢票/main.js': function (_0x31996a, _0x4ac8da, _0x3bd8f4) {
        'ui';
        var _0x179884 = a0_0xc4af;
        function _0x1ba348(_0x21c002, _0x447fbe) {
            var _0x1f67f8 = a0_0xc4af, _0x55423e = _0x1f67f8(0x261) != typeof Symbol && _0x21c002[Symbol[_0x1f67f8(0x1e7)]] || _0x21c002['@@iterator'];
            if (!_0x55423e) {
                if (Array[_0x1f67f8(0x212)](_0x21c002) || (_0x55423e = _0x12b8ac(_0x21c002)) || _0x447fbe && _0x21c002 && _0x1f67f8(0x270) == typeof _0x21c002[_0x1f67f8(0x23f)]) {
                    _0x55423e && (_0x21c002 = _0x55423e);
                    var _0x72bb65 = 0x0, _0x302b6d = function _0x47df3d() {
                        };
                    return {
                        's': _0x302b6d,
                        'n': function _0x29a2d4() {
                            var _0x2eda75 = _0x1f67f8;
                            return _0x72bb65 >= _0x21c002[_0x2eda75(0x23f)] ? { 'done': !0x0 } : {
                                'done': !0x1,
                                'value': _0x21c002[_0x72bb65++]
                            };
                        },
                        'e': function _0x40c4f0(_0x4915bf) {
                            throw _0x4915bf;
                        },
                        'f': _0x302b6d
                    };
                }
                throw new TypeError('Invalid\x20attempt\x20to\x20iterate\x20non-iterable\x20instance.\x0aIn\x20order\x20to\x20be\x20iterable,\x20non-array\x20objects\x20must\x20have\x20a\x20[Symbol.iterator]()\x20method.');
            }
            var _0x92a7c1, _0x3ae84c = !0x0, _0x36490c = !0x1;
            return {
                's': function _0x4c0ecf() {
                    var _0x574c0d = _0x1f67f8;
                    _0x55423e = _0x55423e[_0x574c0d(0x1de)](_0x21c002);
                },
                'n': function _0x40deea() {
                    var _0x10bb3d = _0x1f67f8, _0x5ac798 = _0x55423e[_0x10bb3d(0x214)]();
                    return _0x3ae84c = _0x5ac798[_0x10bb3d(0x272)], _0x5ac798;
                },
                'e': function _0x5af7bb(_0x17b3d1) {
                    _0x36490c = !0x0, _0x92a7c1 = _0x17b3d1;
                },
                'f': function _0x3b33b6() {
                    try {
                        _0x3ae84c || null == _0x55423e['return'] || _0x55423e['return']();
                    } finally {
                        if (_0x36490c)
                            throw _0x92a7c1;
                    }
                }
            };
        }
        function _0x12b8ac(_0x1d2035, _0x22d545) {
            var _0x4d786c = a0_0xc4af;
            if (_0x1d2035) {
                if (_0x4d786c(0x1ef) == typeof _0x1d2035)
                    return _0x5e1ffb(_0x1d2035, _0x22d545);
                var _0x1bb2ad = {}[_0x4d786c(0x1cf)][_0x4d786c(0x1de)](_0x1d2035)['slice'](0x8, -0x1);
                return _0x4d786c(0x208) === _0x1bb2ad && _0x1d2035['constructor'] && (_0x1bb2ad = _0x1d2035['constructor'][_0x4d786c(0x1c8)]), _0x4d786c(0x234) === _0x1bb2ad || _0x4d786c(0x1c6) === _0x1bb2ad ? Array[_0x4d786c(0x1be)](_0x1d2035) : _0x4d786c(0x221) === _0x1bb2ad || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/['test'](_0x1bb2ad) ? _0x5e1ffb(_0x1d2035, _0x22d545) : void 0x0;
            }
        }
        function _0x5e1ffb(_0x457096, _0x10a0eb) {
            var _0x1ca297 = a0_0xc4af;
            (null == _0x10a0eb || _0x10a0eb > _0x457096[_0x1ca297(0x23f)]) && (_0x10a0eb = _0x457096[_0x1ca297(0x23f)]);
            for (var _0x5463e7 = 0x0, _0x1e9e0c = Array(_0x10a0eb); _0x5463e7 < _0x10a0eb; _0x5463e7++)
                _0x1e9e0c[_0x5463e7] = _0x457096[_0x5463e7];
            return _0x1e9e0c;
        }
        ui[_0x179884(0x245)](_0x179884(0x236)), ui[_0x179884(0x248)]['click'](function () {
            var _0x3afccc = _0x179884;
            ui[_0x3afccc(0x210)](function () {
                var _0x20e6ac = _0x3afccc, _0x5cae1d = {
                        'method': ui[_0x20e6ac(0x23a)][_0x20e6ac(0x24e)]() ? ui['yuding'][_0x20e6ac(0x244)] : ui[_0x20e6ac(0x257)][_0x20e6ac(0x24e)]() ? ui[_0x20e6ac(0x257)][_0x20e6ac(0x244)] : ui[_0x20e6ac(0x1e8)][_0x20e6ac(0x244)],
                        'ccArr': ui[_0x20e6ac(0x278)]['text']() ? ui[_0x20e6ac(0x278)]['text']()[_0x20e6ac(0x262)]()[_0x20e6ac(0x233)](/，/g, ',')[_0x20e6ac(0x1e9)](',') : [],
                        'pdArr': ui['pdArr']['text']() ? ui['pdArr']['text']()[_0x20e6ac(0x262)]()['replace'](/，/g, ',')[_0x20e6ac(0x1e9)](',') : [],
                        'needNum': Number(ui[_0x20e6ac(0x1df)]['text']())
                    };
                activity[_0x20e6ac(0x237)](!![]), threads['start'](function () {
                    main(_0x5cae1d);
                });
            });
        }), ui['cancelBtn'][_0x179884(0x228)](function () {
            var _0x59850e = _0x179884;
            engines['myEngine']()[_0x59850e(0x268)]();
        });
        var _0x2e81ac = _0x3bd8f4(_0x179884(0x1e1));
        function main(_0x3b0235) {
            var _0x465125 = _0x179884;
            _0x2e81ac[_0x465125(0x1d7)](), _0x3b0235 = _0x3b0235 || {}, console[_0x465125(0x276)](_0x465125(0x201), _0x3b0235), _0x1e6106(_0x3b0235);
        }
        function _0x1e6106(_0x58beb3) {
            var _0x296542 = _0x179884;
            switch (_0x58beb3[_0x296542(0x1d0)]) {
            case '预定':
                _0x2e81ac[_0x296542(0x275)](_0x58beb3['method'] + '1', function () {
                    return _0x560561(_0x58beb3);
                }, !![]);
                break;
            case '购买':
                _0x2e81ac[_0x296542(0x275)](_0x58beb3[_0x296542(0x1d0)] + '1', function () {
                    var _0x117dab = _0x296542;
                    return _0x5d6b8f(_0x58beb3, _0x58beb3['ccArr'], _0x58beb3[_0x117dab(0x20a)], _0x58beb3['needNum']);
                }, !![]);
                break;
            case '捡漏':
                _0x2e81ac['consoleWrap'](_0x58beb3[_0x296542(0x1d0)] + '1', function () {
                    var _0x5eab00 = _0x296542;
                    return _0x4546fa(_0x58beb3, _0x58beb3[_0x5eab00(0x278)], _0x58beb3[_0x5eab00(0x20a)], _0x58beb3[_0x5eab00(0x1df)]);
                }, !![]);
                break;
            default:
                console[_0x296542(0x22b)]('未知的执行方法');
                break;
            }
        }
        function _0x560561(_0xa50866) {
            var _0xe62757 = _0x179884, _0x1e02ba = arguments[_0xe62757(0x23f)] > 0x1 && arguments[0x1] !== undefined ? arguments[0x1] : 0x1;
            if (_0x1e02ba == 0x1) {
                var _0x139149 = textMatches(_0xe62757(0x238))['untilFind']();
                _0x2e81ac['clickXyRect'](_0x139149[0x0]), log(_0xe62757(0x26c));
            }
            log(_0xe62757(0x25a));
            var _0x257c5f = text('确定')['untilFind']();
            _0x2e81ac[_0xe62757(0x1ec)](_0x257c5f[0x0]), sleep(0xc8), log(_0xe62757(0x1bc));
            try {
                !text('提交订单')[_0xe62757(0x1d2)](0x1f4) && _0x5dac3a(_0xa50866[_0xe62757(0x278)], _0xa50866[_0xe62757(0x20a)], _0xa50866[_0xe62757(0x1df)], 0x1, null, '预定');
                var _0x55d185 = _0x12e905(text(_0xe62757(0x1ba)), 0x64);
                if (_0x55d185) {
                    log(_0xe62757(0x1db));
                    return;
                }
            } catch (_0x44e590) {
                _0xa50866[_0xe62757(0x1d0)] = '捡漏', _0x1e6106(_0xa50866);
            }
            device['vibrate'](0x3e8 * 0x3c);
        }
        function _0x5d6b8f(_0x591edf, _0xb1d510, _0x5dcf54, _0x3c1e1e) {
            var _0x2b7d43 = _0x179884, _0x136a4f = arguments['length'] > 0x4 && arguments[0x4] !== undefined ? arguments[0x4] : 0x1, _0x43bc87 = function _0x5ccde9() {
                    return _0x5d6b8f(_0xb1d510, _0x5dcf54, _0x3c1e1e, _0x136a4f);
                };
            if (_0x136a4f == 0x1) {
                var _0x518831 = textMatches(_0x2b7d43(0x238))['untilFind']();
                _0x2e81ac[_0x2b7d43(0x1fb)](_0x518831[0x0]), log(_0x2b7d43(0x26c));
            }
            _0x5dac3a(_0xb1d510, _0x5dcf54, _0x3c1e1e, _0x136a4f, _0x43bc87, '购买'), log(_0x2b7d43(0x1bc));
            try {
                var _0x24f369 = _0x12e905(text(_0x2b7d43(0x1ba)), 0x64);
                if (_0x24f369) {
                    log('还是存在提交订单按钮，进入下一页失败...');
                    return;
                }
            } catch (_0x3510ae) {
                _0x3510ae[_0x2b7d43(0x26b)] == _0x2b7d43(0x224) && (_0x591edf[_0x2b7d43(0x1d0)] = '捡漏', _0x1e6106(_0x591edf));
            }
            device[_0x2b7d43(0x1f5)](0x3e8 * 0x3c);
        }
        function _0x4546fa(_0x199f1d, _0x3d9112, _0x4c876a, _0x387693) {
            var _0x498d69 = _0x179884, _0x5d1528 = arguments[_0x498d69(0x23f)] > 0x4 && arguments[0x4] !== undefined ? arguments[0x4] : 0x1, _0x42ec50 = function _0x326f18() {
                    return _0x4546fa(_0x3d9112, _0x4c876a, _0x387693, _0x5d1528);
                };
            _0x5dac3a(_0x3d9112, _0x4c876a, _0x387693, _0x5d1528, _0x42ec50, '捡漏'), log('开始提交订单...');
            try {
                var _0x283f13 = _0x12e905(text(_0x498d69(0x1ba)));
                !_0x283f13 && _0x2e81ac[_0x498d69(0x275)]('捡漏' + ++_0x5d1528, _0x42ec50, !![]);
            } catch (_0xfe4dcb) {
                _0xfe4dcb[_0x498d69(0x26b)] == 'back' && _0x2e81ac[_0x498d69(0x275)]('捡漏' + ++_0x5d1528, _0x42ec50, !![]);
            }
            device[_0x498d69(0x1f5)](0x3e8 * 0x3c);
        }
        function _0x5dac3a(_0x194dd6, _0x21b8fa, _0x5efbb7, _0x4afbe3, _0x1e98f4, _0x16e423) {
            var _0x54c938 = _0x179884;
            log(_0x54c938(0x266));
            var _0x3cd3f6 = _0x2e81ac['parents'](text('场次')[_0x54c938(0x1d2)](), 0x2), _0x448026 = _0x3cd3f6[_0x54c938(0x1c5)]()[0x1][_0x54c938(0x1c5)]()['filter'](function (_0x4fa435) {
                    var _0x4d7ced = _0x54c938;
                    return _0x4fa435[_0x4d7ced(0x1d8)](id(_0x4d7ced(0x1c9)));
                });
            if (_0x448026['length'] > 0x1) {
                var _0x56de72 = _0x3a963a(_0x448026, function () {
                    var _0x6c787 = _0x54c938, _0x280eb0 = text('预售')['findOne'](0x64);
                    if (!_0x280eb0)
                        return null;
                    log(_0x6c787(0x226));
                    var _0x56f797 = ![];
                    if (_0x194dd6 && _0x194dd6[_0x6c787(0x23f)] > 0x0) {
                        var _0xc4cf90 = _0x2e81ac['parents'](_0x280eb0, 0x7)['children'](), _0x2e120c = _0xc4cf90['filter'](function (_0x3cb8df) {
                                var _0x4cf518 = _0x6c787;
                                return _0x3cb8df[_0x4cf518(0x1d2)](textMatches(_0x4cf518(0x255) + _0x194dd6[_0x4cf518(0x1e2)](function (_0x2c00d3) {
                                    var _0xd1e969 = _0x4cf518;
                                    return _0x2c00d3[_0xd1e969(0x262)]();
                                })[_0x4cf518(0x1ff)]('|') + ').*/'));
                            })[0x0];
                        _0x2e120c && (_0x56f797 = !![]);
                    } else
                        _0x56f797 = !![];
                    return _0x56f797 ? _0x280eb0 : null;
                }, 0x0);
                log(_0x54c938(0x22d)), _0x2e81ac[_0x54c938(0x1ec)](_0x56de72);
            } else {
                log(_0x54c938(0x1ea)), _0x2e81ac['clickXy'](_0x448026[0x0]);
                if (_0x16e423 === '捡漏') {
                    var _0x471ba0 = id('layout_price')[_0x54c938(0x21e)](), _0x3df65a = _0x471ba0[0x0][_0x54c938(0x1d8)](id(_0x54c938(0x1c9)));
                    _0x3a963a(_0x3df65a, function (_0x2fc278) {
                        var _0x422fe5 = _0x54c938, _0x13cd56 = !_0x21b8fa || _0x21b8fa[_0x422fe5(0x23f)] <= 0x0 || _0x2fc278[_0x422fe5(0x1d2)](textMatches(_0x422fe5(0x255) + _0x21b8fa[_0x422fe5(0x1e2)](function (_0x31e806) {
                                var _0xb22bf6 = _0x422fe5;
                                return _0x31e806[_0xb22bf6(0x262)]();
                            })[_0x422fe5(0x1ff)]('|') + _0x422fe5(0x20d)));
                        if (_0x13cd56) {
                            var _0x12dd19 = _0x2fc278['findOne'](text(_0x422fe5(0x23e)));
                            if (!_0x12dd19)
                                return _0x2fc278;
                        }
                        return null;
                    }, 0x0);
                }
            }
            _0x448026[_0x54c938(0x23f)] > 0x4 && _0x2e81ac[_0x54c938(0x22e)](0x2bc, 0x5dc, 0x320, 0x258, 0xc8);
            log(_0x54c938(0x232));
            var _0x32afb5 = id(_0x54c938(0x24d))[_0x54c938(0x21e)](), _0x31872d = _0x32afb5[0x0][_0x54c938(0x1d8)](id(_0x54c938(0x1c9))), _0x237354 = _0x31872d[_0x54c938(0x24c)](function (_0x2b2dd9) {
                    var _0x4f1675 = _0x54c938, _0x2ed7d9 = !_0x21b8fa || _0x21b8fa['length'] <= 0x0 || _0x2b2dd9[_0x4f1675(0x1d2)](textMatches('/.*(' + _0x21b8fa[_0x4f1675(0x1e2)](function (_0x462c2b) {
                            var _0x3d973a = _0x4f1675;
                            return _0x462c2b[_0x3d973a(0x262)]();
                        })[_0x4f1675(0x1ff)]('|') + _0x4f1675(0x20d)));
                    if (_0x2ed7d9) {
                        var _0x3005e8 = _0x2b2dd9[_0x4f1675(0x1d2)](text(_0x4f1675(0x23e)));
                        if (!_0x3005e8)
                            return !![];
                    }
                    return ![];
                })[0x0];
            _0x237354 ? (log(_0x54c938(0x1f0)), _0x2e81ac[_0x54c938(0x1ec)](_0x237354), sleep(0xc8)) : (log('无匹配票档，重新刷新...'), _0x448026[_0x54c938(0x23f)] > 0x4 && _0x2e81ac[_0x54c938(0x22e)](0x320, 0x258, 0x2bc, 0x5dc, 0xc8), _0x2e81ac[_0x54c938(0x275)](_0x16e423 + ++_0x4afbe3, _0x1e98f4, !![]));
            if (_0x16e423 !== '预定') {
                log(_0x54c938(0x250));
                for (var _0x4c2988 = 0x1; _0x4c2988 < _0x5efbb7; _0x4c2988++) {
                    var _0x435be1 = id(_0x54c938(0x1ed))['findOne'](0x3e8);
                    _0x2e81ac[_0x54c938(0x1ec)](_0x435be1), sleep(0x64);
                }
            }
            log(_0x54c938(0x25a));
            var _0x3ef739 = text('确定')[_0x54c938(0x21e)]();
            _0x2e81ac[_0x54c938(0x1ec)](_0x3ef739[0x0]), sleep(0xc8), log(_0x54c938(0x1d6));
            var _0x104d49 = text(_0x54c938(0x264))[_0x54c938(0x21e)](), _0x4a68ae = _0x1ba348(_0x104d49), _0x2abca8;
            try {
                for (_0x4a68ae['s'](); !(_0x2abca8 = _0x4a68ae['n']())[_0x54c938(0x272)];) {
                    var _0x3d4fdf = _0x2abca8[_0x54c938(0x1e0)];
                    _0x2e81ac[_0x54c938(0x1ec)](_0x3d4fdf), sleep(0x64);
                }
            } catch (_0x164eca) {
                _0x4a68ae['e'](_0x164eca);
            } finally {
                _0x4a68ae['f']();
            }
        }
        function _0x12e905(_0x4a7c49) {
            var _0x1ea7b4 = _0x179884, _0x414add = arguments[_0x1ea7b4(0x23f)] > 0x1 && arguments[0x1] !== undefined ? arguments[0x1] : 0x3, _0x4fed1f = arguments[_0x1ea7b4(0x23f)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : 0x1f4, _0x59b393 = 0x0, _0xd08706 = _0x4a7c49[_0x1ea7b4(0x21e)]();
            while (_0xd08706) {
                _0xd08706 = _0x4a7c49[_0x1ea7b4(0x1d2)]();
                _0xd08706 && (log('第'[_0x1ea7b4(0x22f)](_0x59b393 + 0x1, _0x1ea7b4(0x25c))), _0x2e81ac[_0x1ea7b4(0x1ec)](_0xd08706), sleep(random(_0x4fed1f - 0x64, _0x4fed1f + 0x64)), _0xd08706 = _0x4a7c49['findOne'](0x3e8));
                if (!_0xd08706) {
                    var _0x1db2e5 = textMatches('/.*(努力刷新|继续尝试|操作过于频繁|我知道了).*/')[_0x1ea7b4(0x1d2)](0x3e8);
                    if (_0x1db2e5 && _0x1db2e5['length'] > 0x0) {
                        if (text(_0x1ea7b4(0x1cc))[_0x1ea7b4(0x1d2)](0x3e8) || text(_0x1ea7b4(0x246))['findOne'](0x3e8))
                            log(_0x1ea7b4(0x235)), _0x2e81ac[_0x1ea7b4(0x1fb)](_0x1db2e5[0x0]), log(_0x1ea7b4(0x1fe));
                        else {
                            if (text(_0x1ea7b4(0x253))[_0x1ea7b4(0x1d2)](0x3e8))
                                log(_0x1ea7b4(0x1c3)), _0x2e81ac['swipeRandom'](0xb4, 0x604, 0x3de, 0x604, 0xc8), log(_0x1ea7b4(0x1fa));
                            else {
                                if (text('我知道了')[_0x1ea7b4(0x1d2)](0x3e8)) {
                                    _0x2e81ac[_0x1ea7b4(0x1ec)](text(_0x1ea7b4(0x26d))['findOne']()), log('已点击我知道了...');
                                    throw new Error(_0x1ea7b4(0x224));
                                } else
                                    return !![];
                            }
                        }
                    } else {
                        log(_0x1ea7b4(0x218));
                        throw new Error(_0x1ea7b4(0x224));
                    }
                }
                if (_0x59b393 >= _0x414add)
                    return ![];
                _0x59b393++;
            }
        }
        function _0x3a963a(_0x2fb90a, _0x4536d0) {
            var _0x5e1303 = _0x179884, _0x4fa88d = arguments[_0x5e1303(0x23f)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : 0x3, _0x502fe9 = arguments[_0x5e1303(0x23f)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : 0x320, _0x1889b3 = 0x0, _0x357dbc = 0x0;
            while (_0x1889b3 < _0x4fa88d || _0x4fa88d == 0x0) {
                var _0x55f339 = _0x2fb90a[_0x357dbc];
                _0x2e81ac[_0x5e1303(0x1ec)](_0x55f339), console[_0x5e1303(0x276)]('已点击刷新...'), sleep(random(_0x502fe9 - 0x64, _0x502fe9 + 0x64));
                var _0xe9d996 = _0x4536d0(_0x55f339);
                if (_0xe9d996)
                    return _0xe9d996;
                _0x357dbc++, _0x357dbc > _0x2fb90a[_0x5e1303(0x23f)] - 0x1 && (_0x357dbc = 0x0);
            }
            return null;
        }
    }
}));